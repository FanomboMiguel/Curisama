# Rulombo Discord — Android starter

Proyecto Android nativo (Kotlin + Jetpack Compose) con registro/inicio de sesión Firebase, perfiles básicos, búsqueda de usuarios y envío de solicitudes de amistad.

## Para abrir
1. Instala Android Studio en una computadora.
2. Abre esta carpeta como proyecto.
3. Crea un proyecto Firebase en https://console.firebase.google.com/ y registra la app Android con el paquete `com.rulombo.discord`.
4. Descarga `google-services.json` y colócalo en `app/google-services.json`.
5. Activa Authentication > Email/Password y crea Firestore Database.
6. Publica las reglas de `firestore.rules` en Firebase.
7. Sin `google-services.json`, Firebase no puede conectarse y el proyecto no iniciará sesión.

## Estado honesto de esta entrega
- Incluye: app Android fuente, registro/login, perfiles de texto, búsqueda por username y solicitud de amistad, interfaz de chat de demostración.
- Aún requiere desarrollo/configuración: mensajes persistentes en tiempo real y membresía/aceptación de amigos, subida de fotos a Storage, notificaciones, llamadas de voz/vídeo con WebRTC/servicio de señalización, moderación y pruebas.
- No incluye APK compilado ni servidor publicado. Para usuarios reales hacen falta un proyecto Firebase y configuración de llamadas; no compartas claves privadas en chats públicos.

## Seguridad antes de publicar
Añade verificación de edad apropiada, controles de privacidad, bloqueo/denuncia, límites anti-spam, reglas de acceso por miembros de cada chat y herramientas de moderación. Las reglas incluidas son solo un punto de partida y NO son suficientes para una app pública.
