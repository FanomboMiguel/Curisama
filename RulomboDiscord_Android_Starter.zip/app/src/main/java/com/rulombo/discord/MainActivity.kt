package com.rulombo.discord

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private val Ink = Color(0xFF17151F)
private val Panel = Color(0xFF211E2B)
private val Purple = Color(0xFF8960C9)
private val Soft = Color(0xFFBDB5CB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary=Purple, background=Ink, surface=Panel)) { RulomboApp() } }
    }
}

@Composable fun RulomboApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var tab by remember { mutableStateOf("Chat") }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Surface(Modifier.fillMaxSize(), color=Ink) {
        if (user == null) {
            Column(Modifier.fillMaxSize().padding(26.dp), verticalArrangement=Arrangement.Center) {
                Text("RULOMBO", color=Purple, style=MaterialTheme.typography.headlineLarge, fontWeight=FontWeight.Black)
                Text("DISCORD", color=Color.White, style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(28.dp))
                Text("Crea tu cuenta o inicia sesión", color=Soft)
                OutlinedTextField(username,{username=it},label={Text("Nombre de usuario")},modifier=Modifier.fillMaxWidth())
                OutlinedTextField(email,{email=it},label={Text("Correo electrónico")},modifier=Modifier.fillMaxWidth())
                OutlinedTextField(password,{password=it},label={Text("Contraseña")},modifier=Modifier.fillMaxWidth())
                if(error.isNotBlank()) Text(error,color=Color(0xFFFF8585))
                Spacer(Modifier.height(12.dp))
                Button(onClick={
                    scope.launch {
                        busy=true; error=""
                        try {
                            val result=auth.createUserWithEmailAndPassword(email.trim(),password).await()
                            val uid=result.user!!.uid
                            FirebaseFirestore.getInstance().collection("users").document(uid).set(
                                mapOf("uid" to uid,"username" to username.trim(),"usernameLower" to username.trim().lowercase(),"photoUrl" to "","status" to "Disponible")
                            ).await()
                            user=auth.currentUser
                        } catch(e:Exception){ error=e.localizedMessage ?: "No se pudo crear la cuenta" }
                        busy=false
                    }
                },modifier=Modifier.fillMaxWidth(),enabled=!busy && username.isNotBlank() && email.isNotBlank() && password.length>=8) { Text(if(busy)"Procesando…" else "Crear cuenta") }
                OutlinedButton(onClick={
                    scope.launch { busy=true; error=""
                        try { auth.signInWithEmailAndPassword(email.trim(),password).await(); user=auth.currentUser }
                        catch(e:Exception){error=e.localizedMessage ?: "No se pudo iniciar sesión"}
                        busy=false
                    }
                },modifier=Modifier.fillMaxWidth(),enabled=!busy && email.isNotBlank() && password.isNotBlank()) { Text("Iniciar sesión") }
                Text("Usa una contraseña segura y no compartas tus datos de acceso.",color=Soft,style=MaterialTheme.typography.bodySmall)
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(Panel).padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("RULOMBO DISCORD",color=Purple,fontWeight=FontWeight.Black); Text("Conectado • ${user!!.email}",color=Soft,style=MaterialTheme.typography.labelSmall) }
                    IconButton(onClick={auth.signOut();user=null}) { Icon(Icons.Default.Logout,"Cerrar sesión") }
                }
                when(tab) {
                    "Chat" -> ChatScreen(user!!.uid)
                    "Amigos" -> FriendsScreen(user!!.uid)
                    else -> ProfileScreen(user!!.uid)
                }
                NavigationBar(containerColor=Panel) {
                    listOf("Chat","Amigos","Perfil").forEach { item ->
                        NavigationBarItem(selected=tab==item,onClick={tab=item},icon={
                            Icon(when(item){"Chat"->Icons.Default.Chat; "Amigos"->Icons.Default.People;else->Icons.Default.Person},"")
                        },label={Text(item)})
                    }
                }
            }
        }
    }
}

@Composable fun ChatScreen(uid:String) {
    var friend by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<Pair<String,String>>()) }
    var status by remember { mutableStateOf("Escribe tu primer mensaje") }
    val db= remember { FirebaseFirestore.getInstance() }
    val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Canal general",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text("Comunidad Rulombo",color=Soft)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(messages){ m -> Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Panel)) {
                Column(Modifier.padding(12.dp)){Text(m.first,color=Purple,fontWeight=FontWeight.Bold);Text(m.second)}
            } }
        }
        Text(status,color=Soft,style=MaterialTheme.typography.labelSmall)
        Row(verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(text,{text=it},modifier=Modifier.weight(1f),placeholder={Text("Mensaje…")},maxLines=3)
            IconButton(onClick={
                if(text.isNotBlank()){
                    val msg=text.trim(); messages=messages+("Tú" to msg); text=""
                    status="Mensaje guardado solo en esta sesión. Configura una conversación para mensajería online."
                }
            }) { Icon(Icons.Default.Send,"Enviar",tint=Purple) }
        }
        Row(verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.Call,color=Soft,contentDescription="Llamada")
            Text(" Las llamadas reales se activan al conectar un servicio de voz y señalización.",color=Soft,style=MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable fun FriendsScreen(uid:String) {
    var query by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var found by remember { mutableStateOf(false) }
    val scope= rememberCoroutineScope()
    val db= remember { FirebaseFirestore.getInstance() }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Amigos",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Busca por nombre de usuario exacto.",color=Soft)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),label={Text("@usuario")})
        Button(onClick={
            scope.launch {
                try {
                    val docs=db.collection("users").whereEqualTo("usernameLower",query.trim().removePrefix("@").lowercase()).limit(1).get().await()
                    if(docs.isEmpty){result="No encontramos ese usuario.";found=false}
                    else {
                        val d=docs.documents.first()
                        if(d.id==uid){result="Ese es tu propio perfil.";found=false}
                        else {
                            db.collection("friendRequests").document("${uid}_${d.id}").set(mapOf("from" to uid,"to" to d.id,"status" to "pending","createdAt" to System.currentTimeMillis())).await()
                            result="Solicitud enviada a @${d.getString("username")}";found=true
                        }
                    }
                } catch(e:Exception){result="Error: ${e.localizedMessage}"}
            }
        },enabled=query.isNotBlank()) { Icon(Icons.Default.PersonAdd,null);Text("  Añadir amigo") }
        Spacer(Modifier.height(12.dp))
        Text(result,color=if(found)Purple else Soft)
        Spacer(Modifier.height(20.dp))
        Text("Consejo: comparte tu nombre de usuario, nunca tu contraseña.",color=Soft)
    }
}

@Composable fun ProfileScreen(uid:String) {
    var name by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Disponible") }
    var info by remember { mutableStateOf("") }
    val scope= rememberCoroutineScope()
    val db= remember { FirebaseFirestore.getInstance() }
    LaunchedEffect(uid) {
        try { val d=db.collection("users").document(uid).get().await(); name=d.getString("username") ?: "" }
        catch(_:Exception){}
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Tu perfil",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Box(Modifier.size(76.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text("R",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Black)}
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(name,{name=it},modifier=Modifier.fillMaxWidth(),label={Text("Nombre de usuario")})
        Text("Estado",color=Soft)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Disponible","Ausente","No molestar").forEach { s -> FilterChip(selected=status==s,onClick={status=s},label={Text(s)}) }
        }
        Button(onClick={
            scope.launch {
                try {
                    db.collection("users").document(uid).update(mapOf("username" to name.trim(),"usernameLower" to name.trim().lowercase(),"status" to status)).await()
                    info="Perfil actualizado"
                } catch(e:Exception){info=e.localizedMessage ?: "No se pudo guardar"}
            }
        },enabled=name.isNotBlank()) { Text("Guardar perfil") }
        Text(info,color=Purple)
        Text("La foto de perfil se habilitará al configurar Firebase Storage y el selector de imágenes.",color=Soft)
    }
}
